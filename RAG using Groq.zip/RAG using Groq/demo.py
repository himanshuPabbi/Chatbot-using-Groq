import streamlit as st
from groq import Groq
import pdfplumber
import os

# Initialize the Groq client with your API key
api_key = "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"  # Replace with your actual Groq API key
client = Groq(api_key=api_key)

# Function to extract text from PDF using pdfplumber
def extract_text_from_pdf(pdf_path):
    text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text += page.extract_text()
    return text

# Function to trim the PDF text to avoid exceeding token limits
def trim_text(text, max_tokens=3000):
    # Simple way to trim text to approximate token limits
    tokens = text.split()
    if len(tokens) > max_tokens:
        return ' '.join(tokens[:max_tokens])
    return text

# Function to handle the chatbot conversation with Groq
def chatbot(query, pdf_text):
    # Create the message payload
    messages = [
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": f"Answer the following question based on the provided document:\n{pdf_text}\n\nQuestion: {query}"}
    ]
    
    # Make a request to the Groq API for a chat completion
    chat_completion = client.chat.completions.create(
        messages=messages,
        model="llama3-8b-8192",  # You can use a different model if preferred
        temperature=0.7,  # Control response randomness
        max_tokens=300,   # Limit response length
        top_p=1,          # Diversity control
        stop=None,        # No stop sequence
        stream=False      # Do not stream the response
    )
    
    # Return the chatbot's response
    return chat_completion.choices[0].message.content

# Streamlit UI
st.title("RAG using Groq for PDF-based Q&A")

# PDF Upload
pdf_file = st.file_uploader("Upload a PDF", type=["pdf"])

# User Query
user_query = st.text_input("Ask a question about the document:", "")

# When the user uploads a PDF and submits a question
if pdf_file and user_query:
    # Save the uploaded PDF to a temporary file
    pdf_path = "uploaded_pdf.pdf"
    with open(pdf_path, "wb") as f:
        f.write(pdf_file.read())
    
    # Extract text from the uploaded PDF
    pdf_text = extract_text_from_pdf(pdf_path)
    
    # Trim the text to avoid token limit issues
    trimmed_pdf_text = trim_text(pdf_text)
    
    # Get response from the chatbot based on the query and the PDF content
    response = chatbot(user_query, trimmed_pdf_text)
    
    # Display the response
    st.write("Chatbot:", response)
    
    # Remove the uploaded PDF file after processing
    os.remove(pdf_path)

# Clear chat button (optional)
if st.button("Clear Chat"):
    st.experimental_rerun()  # Clear chat and reset the app
